import React, { useState } from 'react'
import '../css/join.css';

function Join() {
  const [id, setId] = useState("");
  const [pwd, setPwd] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const onSubmit = () => {

  }

  return (
    <div id="wrap" align="center">
      <form>
        <table>
          <tr><th>아이디</th><td><input type="text" value={id} onChange={
            (e) => {
              setId(e.currentTarget.value);
            }
          } /></td></tr>
          <tr><th>암호</th><td><input type="password" value={pwd} onChange={
            (e) => {
              setPwd(e.currentTarget.value);
            }
          } /></td></tr>

          <tr><th>이름</th><td><input type="text" value={name} onChange={
            (e) => {
              setName(e.currentTarget.value);
            }
          } />*</td></tr>

          <tr><th>이메일</th><td><input type="text"
            value={email} onChange={
              (e) => {
                setEmail(e.currentTarget.value);
              }
            } />*</td></tr>
        </table>
        <button onClick={
          () => {
            onsubmit();
          }
        }>회원가입</button>
      </form>
    </div>
  )
}

export default Join
